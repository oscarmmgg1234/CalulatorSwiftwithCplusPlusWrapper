//
//  wrapper.cpp
//  calculator++
//
//  Created by Oscar Maldonado on 4/14/19.
//  Copyright © 2019 Oscar Maldonado. All rights reserved.
//

#include "calcCore.h"
extern "C" void getA()
{
    storeA a;
    a.insertC('a', 3);
    
}
